import countries from "@/services/countries";
import data from "@/services/data-passengers";

interface Passenger {
  id: number;
  passenger_name: string;
  passenger_avatar: string;
  origin: string;
  destination: string;
}

export function addPassengersToCountries() {
  data.forEach((passenger: Passenger) => {
    const originCountry = countries.find(
      (country) => country.name === passenger.origin
    );
    const destinationCountry = countries.find(
      (country) => country.name === passenger.destination
    );
    if (originCountry) {
      originCountry.info.push({
        id: passenger.id,
        name: passenger.passenger_name,
      });
    }
    if (destinationCountry) {
      destinationCountry.info.push({
        id: passenger.id,
        name: passenger.passenger_name,
      });
    }
  });
} // Adicionando passageiros aos países
addPassengersToCountries();
