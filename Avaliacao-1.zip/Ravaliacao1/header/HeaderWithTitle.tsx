import {
  View,
  Text,
  Touchable,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import React from "react";
import { Stack, usePathname, router, useRouter } from "expo-router";
import {
  ActionSheetProvider,
  useActionSheet,
} from "@expo/react-native-action-sheet";
import SimpleLineIcons from "@expo/vector-icons/SimpleLineIcons";
import { canDismiss } from "expo-router/build/global-state/routing";

type HeaderWithTitleProps = {
  log?: { name: string; path: string };
};

export default function HeaderWithTitle({ log }: HeaderWithTitleProps) {
  const pathname = usePathname();
  const router = useRouter();

  const { showActionSheetWithOptions } = useActionSheet();

  const optionsL = ["logout", "sobre", "cancelar"];
  const opabout = ["logout", "cancelar"];
  const destructiveButtonIndex = 0;
  const cancelButtonIndex = 2;
  const isAboutPage = pathname === "/sobre";
  const options = isAboutPage ? opabout : optionsL;

  const handleBurguer = () => {
    showActionSheetWithOptions(
      {
        options,
        cancelButtonIndex,
        destructiveButtonIndex,
      },
      (buttonIndex) => {
        switch (buttonIndex) {
          case 0:
            if (router.canDismiss()) router.dismissAll();
            router.replace("/");

            break;

          case 1:
            if (!isAboutPage) {
              router.push("/sobre");
            }
            break;
          default:
            break;
        }
      }
    );
  };
  return (
    <Stack.Screen
      options={{
        headerRight: () => (
          <ActionSheetProvider>
            <View style={styles.container}>
              <TouchableOpacity onPress={handleBurguer}>
                <SimpleLineIcons name="menu" size={24} color="black" />
              </TouchableOpacity>
            </View>
          </ActionSheetProvider>
        ),
      }}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "flex-end",
    justifyContent: "center",
  },
});
