import { View, Text, StyleSheet, Image, Alert } from "react-native";
import React from "react";
import { router } from "expo-router";
import TextInputex from "@/components/LoginInputs";
import Card from "@/components/Card";
import HeaderHidden from "@/header/HeaderHiden";

export default function index() {
  return (
    <View style={styles.container}>
      <HeaderHidden />
      <Card>
        <View
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
        >
          <Image
            source={require("../assets/images/Aviao.jpg")}
            style={{ width: 200, height: 200 }}
          />
        </View>
      </Card>

      <TextInputex></TextInputex>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    alignSelf: "center",
    flex: 1,
    backgroundColor: "white",
  },
  login: {},
});
