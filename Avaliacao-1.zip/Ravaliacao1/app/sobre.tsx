import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Linking,
} from "react-native";
import React from "react";
import HeaderWithTitle from "@/header/HeaderWithTitle";
import { ActionSheetProvider } from "@expo/react-native-action-sheet";

export default function sobre() {
  const openGitHubRepo = () => {
    Linking.openURL("https://github.com/Vinicius-FPach/Prova_movel1"); // Substitua pelo seu link do GitHub
  };
  return (
    <ActionSheetProvider>
      <View style={styles.container}>
        <HeaderWithTitle />
        <Text style={styles.Logo}>AirDuty</Text>
        <Text style={styles.title}>Meu Repositório no GitHub</Text>
        <TouchableOpacity style={styles.button} onPress={openGitHubRepo}>
          <Text style={styles.buttonText}>Abrir GitHub</Text>
        </TouchableOpacity>
      </View>
    </ActionSheetProvider>
  );
}

const styles = StyleSheet.create({
  Logo: {
    alignSelf: "center",
    justifyContent: "center",
    fontSize: 20,
    fontWeight: "bold",
  },
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
  button: {
    backgroundColor: "#007bff",
    padding: 10,
    alignItems: "center",
    borderRadius: 5,
  },
  buttonText: { color: "#fff", fontWeight: "bold" },
});
