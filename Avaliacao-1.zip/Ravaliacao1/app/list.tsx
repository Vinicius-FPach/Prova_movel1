import {
  View,
  Text,
  SectionList,
  StyleSheet,
  SafeAreaView,
} from "react-native";
import React, { useEffect } from "react";
import { ScrollView } from "react-native-reanimated/lib/typescript/Animated";

//import HeaderWithTitle from "@/header/HeaderWithTitle";
import countries from "@/services/countries";
import { addPassengersToCountries } from "@/helpers/ConvertData";
import { ActionSheetProvider } from "@expo/react-native-action-sheet";
import { StatusBar } from "expo-status-bar";
import Card from "@/components/Card";
import HeaderWithTitle from "@/header/HeaderWithTitle";

export default function list() {
  useEffect(() => {
    addPassengersToCountries();
  }, []);

  const sections = countries.map((country) => ({
    title: country.name,
    data: country.info,
  }));
  return (
    <ActionSheetProvider>
      <SafeAreaView>
        <StatusBar style="auto" />
        <HeaderWithTitle />
        <Card>
          <Text style={styles.Logo}>AirDuty</Text>
          <SectionList
            sections={sections}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => (
              <View style={styles.item}>
                <Text>{item.name}</Text>
              </View>
            )}
            renderSectionHeader={({ section: { title } }) => (
              <View style={styles.header}>
                <Text style={styles.headerText}>{title}</Text>
              </View>
            )}
          />
        </Card>
      </SafeAreaView>
    </ActionSheetProvider>
  );
}

const styles = StyleSheet.create({
  Logo: {
    alignSelf: "center",
    justifyContent: "center",
    fontSize: 20,
    fontWeight: "bold",
  },
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    backgroundColor: "#f4f4f4",
    padding: 10,
  },
  headerText: {
    fontWeight: "bold",
    fontSize: 18,
  },
  item: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
  },
});
