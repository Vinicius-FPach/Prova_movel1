import { View, Text, StyleSheet, TextInput, Alert } from "react-native";
import React from "react";
import { SafeAreaView, SafeAreaProvider } from "react-native-safe-area-context";
import { router } from "expo-router";
import LoginButton from "@/components/LoginButton";

const TextInputex = () => {
  const [text, onChangeText] = React.useState("");
  const [number, onChangeNumber] = React.useState("");

  const validateLogin = () => {
    if (text === "fulano" && number === "123") {
      // Navegar para outra tela se o login for bem-sucedido
      router.push("/list"); // Substitua 'HomeScreen' pelo nome da sua tela de destino
    } else {
      // Exibir mensagem de erro se as credenciais estiverem incorretas
      Alert.alert("Erro", "Usuário ou senha incorretos");
    }
  };

  return (
    <SafeAreaProvider style={styles.container}>
      <SafeAreaView>
        <TextInput
          style={styles.input}
          onChangeText={onChangeText}
          value={text}
          placeholder="Usuário"
        />
        <TextInput
          secureTextEntry={true}
          style={styles.input}
          onChangeText={onChangeNumber}
          value={number}
          placeholder="Password"
          keyboardType="numeric"
        />
        <LoginButton onPress={validateLogin} />
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
});

export default TextInputex;
