import {
  View,
  Text,
  TouchableOpacity,
  Touchable,
  StyleSheet,
  ImageBackground,
} from "react-native";
import React from "react";

type LoginButtonProps = {
  onPress: () => void;
  customTitle?: string;
};
export default function LoginButton({
  onPress,
  customTitle = "Login!",
}: LoginButtonProps) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.absoluteView}>
        <Text>Login</Text>
      </View>
      <ImageBackground
        source={require("../assets/images/cinza.jpg")}
        style={{ width: 100, height: 100 }}
      />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "gray",
    justifyContent: "center",
    alignItems: "center",
    minHeight: 64,
    flex: 1,
  },
  text: {
    fontSize: 20,
    color: "white",
    fontWeight: "bold",
  },
  absoluteView: {
    flex: 1,
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "transparent",
  },
  imageBackground: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
